package com.te.productmanagement.DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.te.productmanagement.beans.productbeans;

public class productdaoilmpl implements productdao {

	@Override
	public productbeans authenticate(String name, String pwd) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emsPeristenceUnit");
		EntityManager manager = factory.createEntityManager();
		productbeans pb  = manager.find(productbeans.class, pid);

		if (pb != null) {
			if (pb.getPassword().equals(pwd)) {
				return pb;
			} else {
				throw new Exception("Password is wrong");
			}
		} else {
			throw new Exception("Invalid ID");
		}

	}
		return null;
	}

	@Override
	public productbeans getEmployeeData(int pid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteproduct(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addproduct(productbeans pb) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateRecord(productbeans pb) {
		// TODO Auto-generated method stub
		return false;
	}

}
