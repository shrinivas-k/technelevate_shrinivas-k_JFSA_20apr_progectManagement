package com.te.productmanagement.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.te.productmanagement.DAO.productdao;
import com.te.productmanagement.beans.adminbean;
import com.te.productmanagement.beans.productbeans;

public class service implements productservic {
	
    @Autowired
	productdao dao;

	@Override
	public productbeans authenticate(int id, String pwd) {
		if (id <= 0) {
			return null;
		} else {
			return dao.authenticate(id, pwd);
		}

	}
	
	@Override
	public productbeans getproductData(int pid) {
		if (pid <= 0) {
			return null;
		}
		return dao.getproductData(pid);
	}
	@Override
	public boolean deleteEmpData(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addproduct(productbeans  pb) {
		return dao.addproduct(pb);
	}

	@Override
	public boolean updateRecord(productbeans employeeInfoBean) {
		// TODO Auto-generated method stub
		return false;
	}
}
