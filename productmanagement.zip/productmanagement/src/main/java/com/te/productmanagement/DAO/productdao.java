package com.te.productmanagement.DAO;

import com.te.productmanagement.beans.productbeans;

public interface productdao {

	public productbeans authenticate(String name, String pwd);

	public productbeans  getproductData(int pid);

	public boolean deleteproduct(int pid);

	public boolean addproduct( productbeans  pb);

	public boolean updateRecord( productbeans  pb);

	
}
