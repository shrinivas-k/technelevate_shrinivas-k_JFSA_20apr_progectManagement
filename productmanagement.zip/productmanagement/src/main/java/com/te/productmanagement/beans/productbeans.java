package com.te.productmanagement.beans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Primary;

import lombok.Data;
@Data
@Entity
@Table
public class productbeans implements Serializable {
	@Id
	@Column
private int pid;
	@Column
private String pname;
	@Column
private Date mgdate;
	@Column
private double price;
	@Column
private Date exdate;
	@Column
private int quantity;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Date getMgdate() {
		return mgdate;
	}
	public void setMgdate(Date mgdate) {
		this.mgdate = mgdate;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Date getExdate() {
		return exdate;
	}
	public void setExdate(Date exdate) {
		this.exdate = exdate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Object getPassword() {
		// TODO Auto-generated method stub
		return null;
	}
}
