package com.te.productmanagement.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.te.productmanagement.beans.adminbean;
import com.te.productmanagement.beans.productbeans;
import com.te.productmanagement.services.service;
@Controller
public class controller {
	@GetMapping("/login")
	public String getEmpForm() {
		return "login";
	}// getEmpForm

	@PostMapping("/login")
	public String authenticate(int id, String password, HttpServletRequest request, ModelMap map) {
		adminbean ab  = service.authenticate(id, password);
		System.out.println(ab);
		if (ab!= null) {
			HttpSession session = request.getSession();
			session.setAttribute("loggedIn", ab);
//			session.setMaxInactiveInterval(3600);
			map.addAttribute("name", ab.getName());
			return "productSeHome";
		} else {
			map.addAttribute("errMsg", "Invalid Credentials");
			return "login";
		}
	}// authenticate
	@GetMapping("/logout")
	public String logout(HttpSession session, ModelMap map) {
		session.invalidate();
		map.addAttribute("msg", "logout successfull");
		return "login";
	}// logout
	@GetMapping("/getDeleteForm")
	public String getDeleteForm(@SessionAttribute(name = "loggedIn", required = false)productbeans pb,
			ModelMap map) {
		if (pb != null) {
			return "delete";
		} else {
			map.addAttribute("errMsg", "Please Login First");
			return "login";
		}
	}//
	@GetMapping("/delete")
	public String deleteData(int id, @SessionAttribute(name = "loggedIn", required = false)productbeans pb ,
			ModelMap map) {
		if (pb!= null) {
			int pid = 0;
			if (service.deleteproductData(pid)) {
				map.addAttribute("msg", "Data Deleted successfully for id : " + pid);
			} else {
				map.addAttribute("msg", "Could not find Record for id : " + pid);
			}
			return "delete";
		} else {
			map.addAttribute("errMsg", "Please Login First");
			return "login";
		}

	}//
	@GetMapping("/addEmp")
	public String getAddFrom(@SessionAttribute(name = "loggedIn", required = false) productbeans pb,
			ModelMap map) {
		if (pb != null) {
			return "insertproduct";
		} else {
			map.addAttribute("errMsg", "Please Login First");
			return "login";
		}
		

	}//

	@PostMapping("/add")
	public String addEmployee(productbeans pb,
			@SessionAttribute(name = "loggedIn", required = false) productbeans pb1, ModelMap map) {
		if (pb1 != null) {
			if (service.addproducte(pb1)) {
				map.addAttribute("msg", "Successfully Inserted");
			} else {
				map.addAttribute("msg", "Failed to Insert");
			}
			return "insertproduct";
		} else {
			map.addAttribute("errMsg", "Please Login First");
			return "login";
		}

	}// add Employee
	@GetMapping("/updateEmployee")
	public String getUpadatePage(@SessionAttribute(name = "loggedIn", required = false) productbeans pb ,
			ModelMap map) {
		if (pb != null) {
			map.addAttribute("pid", pb);
			return "updateEmployee";
		} else {
			map.addAttribute("errMsg", "Please Login First");
			return "login";

		}
	}//
	@PostMapping("/update")
	public String updateEmployeeData(@SessionAttribute(name = "loggedIn", required = false)productbeans pb,
			ModelMap map,productbeans pb1) {
		if (pb1!= null) {
			if (service.updateRecord(pb1)) {
				map.addAttribute("msg", "Updated Successfully");
				map.addAttribute("pid", pb1);
			} else {
				map.addAttribute("msg", "Updation Failed");
				map.addAttribute("id", pb1);
			}
			return "update";
		} else {
			map.addAttribute("errMsg", "Please Login First");
			return "login";
		}
	}//



}
