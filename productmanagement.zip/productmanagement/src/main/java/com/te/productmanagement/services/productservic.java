package com.te.productmanagement.services;

import java.util.List;

import com.te.productmanagement.beans.productbeans;

public interface productservic {
	public productbeans authenticate(int id, String pwd);

	public  productbeans getEmployeeData(int id);

	public boolean deleteEmpData(int id);
	
	public boolean addEmployee( productbeans employeeInfoBean);
	
	public boolean updateRecord( productbeans employeeInfoBean);
	
	public List<productbeans> getAllEmployees();
}
